# Build APK using only an Android phone

This project includes a GitHub Actions workflow to build the debug APK in the cloud.

1. Create or sign in to a GitHub account in your phone browser.
2. Create a new repository and choose **Add file → Upload files**.
3. Extract this ZIP on your phone, then upload the contents of the `GoldBotExness` folder, including the hidden `.github` folder. If the mobile site makes hidden folders difficult, use GitHub's web upload on a browser in desktop mode.
4. Open the repository's **Actions** tab and allow workflows if GitHub asks.
5. Run **Build Gold Bot Exness APK** (or push to the `main` branch to trigger it).
6. When the workflow finishes successfully, open its run page and download the `GoldBotExness-debug-apk` artifact.
7. Extract the downloaded artifact ZIP. Install `app-debug.apk` on Android 9. Allow installation from that browser/file manager if Android asks.

The APK built this way is a debug prototype only. It does not connect to Exness, fetch live prices, or place trades. Use demo-only until real trading integration, API eligibility, secure credential handling, and risk controls have been implemented and tested.
