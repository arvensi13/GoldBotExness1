# Gold Bot Exness — Android starter project

Versi: 0.1.0  
Status: UI prototype / DEMO SIMULATION ONLY

## Isi proyek
- Android app berbasis Kotlin + Jetpack Compose
- Dashboard Gold Bot Exness
- Kontrol simulasi Auto ON/OFF dan Emergency Stop
- Pengaturan risiko simulasi
- Tidak ada koneksi broker atau order trading

## Kebutuhan build
- Android Studio versi stabil yang mendukung Android Gradle Plugin 8.7.3
- JDK 17
- Android SDK 35
- Minimum Android 8.0 (API 26)

## Cara membuka
1. Ekstrak ZIP.
2. Buka folder `GoldBotExness` melalui Android Studio.
3. Tunggu Gradle Sync selesai.
4. Jalankan pada emulator/perangkat Android untuk melihat prototipe.

## Sebelum integrasi Exness
1. Pastikan akun Exness platform-based demo memenuhi persyaratan API di Personal Area.
2. Baca dokumentasi resmi: https://www.exness-api.com/trading/get-started
3. Periksa instrumen yang tersedia dan pastikan simbol Gold/XAUUSD ada untuk akun tersebut.
4. Implementasikan autentikasi, penandatanganan request, REST dan WebSocket sesuai API Reference resmi.
5. Jangan pernah menaruh API Secret di APK. Dokumentasi Exness menyarankan secret disimpan di lingkungan server-side tepercaya. Jika syaratnya benar-benar tanpa VPS/server, minta konfirmasi tertulis Exness tentang metode penyimpanan/koneksi yang mereka izinkan sebelum menghubungkan akun.
6. Uji semua fungsi di akun demo. Jangan aktifkan live trading sebelum validasi order, SL/TP, sizing, reconnect, rate limits, dan emergency stop.

## Batasan
Proyek ini belum menghasilkan APK siap trading. Ini adalah fondasi kode UI yang dapat dibuka dan dikembangkan di Android Studio. Tidak ada strategi live, market data live, atau integrasi API aktif.
