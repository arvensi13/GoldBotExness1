package com.goldbot.exness

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { GoldBotScreen() }
    }
}

@Composable
fun GoldBotScreen() {
    var autoEnabled by remember { mutableStateOf(false) }
    var emergencyStopped by remember { mutableStateOf(false) }
    var risk by remember { mutableFloatStateOf(0.5f) }

    MaterialTheme(colorScheme = darkColorScheme()) {
        Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            Column(
                modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text("GOLD BOT EXNESS", style = MaterialTheme.typography.headlineSmall)
                Text("XAUUSD • AUTO SCALPING • DEMO", color = MaterialTheme.colorScheme.secondary)
                Card {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("STATUS ROBOT", style = MaterialTheme.typography.labelLarge)
                        Text(
                            if (emergencyStopped) "EMERGENCY STOP" else if (autoEnabled) "SIMULASI AKTIF" else "BERHENTI",
                            style = MaterialTheme.typography.headlineMedium
                        )
                        Text("Mode: Demo / simulasi — belum terhubung ke Exness API")
                    }
                }
                Card {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("KONTROL ROBOT", style = MaterialTheme.typography.titleMedium)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Auto Trading", modifier = Modifier.weight(1f))
                            Switch(
                                checked = autoEnabled && !emergencyStopped,
                                onCheckedChange = {
                                    emergencyStopped = false
                                    autoEnabled = it
                                }
                            )
                        }
                        Button(
                            onClick = { autoEnabled = false; emergencyStopped = true },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text("EMERGENCY STOP") }
                        OutlinedButton(
                            onClick = { emergencyStopped = false; autoEnabled = false },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text("Reset ke kondisi berhenti") }
                    }
                }
                Card {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("MANAJEMEN RISIKO", style = MaterialTheme.typography.titleMedium)
                        Text("Risiko per transaksi: ${"%.2f".format(risk)}%")
                        Slider(value = risk, onValueChange = { risk = it }, valueRange = 0.1f..1.0f)
                        Text("Preset proyek: Medium (0,5%). Batas risiko harus diuji di akun demo.")
                        Text("Timeframe strategi: M5")
                        Text("Filter rencana: EMA 50/200 + RSI + spread")
                    }
                }
                Card {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("KONEKSI", style = MaterialTheme.typography.titleMedium)
                        Text("Broker: Exness")
                        Text("API: Belum dikonfigurasi")
                        Text("Instrumen: XAUUSD (perlu cek nama simbol dari daftar instrumen API)")
                    }
                }
                Text(
                    "Peringatan: ini adalah prototipe antarmuka. Tidak membaca harga live, tidak mengirim order, dan tidak menjamin robot berjalan saat Android menghentikan aplikasi.",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.secondary
                )
            }
        }
    }
}
